### 单点登录

#### 三种实现方式

##### 1.session广播机制实现

session的复制过程，把某一个模块中的登录session对象复制到其他的模块中。

缺点：模块如果太多，消耗的资源也会很大。

##### 2.cookie + redis实现

第一步：在项目中的任何一个模块进行登录，登录之后，先后把数据放到redis==(key：生成的唯一标识，value：用户数据)==和cookie==(redis里面生成的key值)==两个地方。

第二步：访问项目中其他模块的时候，发送请求带着cookie发送，获取cookie值后到redis中进行查询，如果查询到了数据就表示已经登录。

可以通过设置redis的过期时间达到跟session一样的效果

##### 3.使用token(自包含令牌)实现

token：按照一定的规则生成的字符串，在字符串中可以包含用户的信息。可以对生成的字符串做编码和加密。

第一步：在项目中的任何一个模块进行登录，登录之后，按照规则生成一个字符串，把登录的用户信息包含到生成字符串里面，把字符串返回。

[^返回]: 字符串可以通过cookie返回，也可以通过地址栏返回。

第二步：访问其他模块的时候，每次访问在地址栏中带着生成的字符串，在访问的模块里面获取地址栏字符串，根据字符串通过解码等方法获取用户信息。如果可以获取到，就表示已登录。

可以通过设置token的过期时间达到跟session一样的效果

**JWT令牌：一种生成token的规则**

三部分：1.jwt头信息；2.有效载荷(包含主体信息，用户信息)；3.签名哈希(防伪标志) | 每部分用.进行隔开



#### 使用

##### 1.引入依赖

```xml
<!-- jwt -->
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
</dependency>
```

##### 2.创建jwt工具类

```java
public class JwtUtils {
    //设置token过期时间
    public static final long EXPIRE = 1000 * 60 * 60 * 24;
    //密钥，用于加密和编码
    public static final String APP_SECRET = "ukc8BDbRigUDaY6pZFfWus2jZWLPHO";

    //生成token字符串
    public static String getJwtToken(String id, String nickname){

        String JwtToken = Jwts.builder()
                //设置jwt头信息
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("alg", "HS256")
                
                //设置过期时间
                .setSubject("guli-user")
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE))
                
                //设置token主体
                .claim("id", id)
                .claim("nickname", nickname)
                
                //生成token字符串的方法
                .signWith(SignatureAlgorithm.HS256, APP_SECRET)
                .compact();

        return JwtToken;
    }

    /**
     * 判断token是否存在与有效
     * @param jwtToken
     * @return
     */
    public static boolean checkToken(String jwtToken) {
        if(StringUtils.isEmpty(jwtToken)) return false;
        try {
            Jwts.parser().setSigningKey(APP_SECRET).parseClaimsJws(jwtToken);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 判断token是否存在与有效
     * @param request
     * @return
     */
    public static boolean checkToken(HttpServletRequest request) {
        try {
            String jwtToken = request.getHeader("token");
            if(StringUtils.isEmpty(jwtToken)) return false;
            Jwts.parser().setSigningKey(APP_SECRET).parseClaimsJws(jwtToken);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 根据token获取会员id
     * @param request
     * @return
     */
    public static String getMemberIdByJwtToken(HttpServletRequest request) {
        String jwtToken = request.getHeader("token");
        if(StringUtils.isEmpty(jwtToken)) return "";
        Jws<Claims> claimsJws = Jwts.parser().setSigningKey(APP_SECRET).parseClaimsJws(jwtToken);
        Claims claims = claimsJws.getBody();
        return (String)claims.get("id");
    }
}
```


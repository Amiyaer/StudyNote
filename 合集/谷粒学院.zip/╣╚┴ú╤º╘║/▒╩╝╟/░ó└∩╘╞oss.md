### 阿里云oss

一个存储服务

#### 使用

##### 1.在maven中引入

```xml
<!--阿里云oss依赖-->
<dependency>
    <groupId>com.aliyun.oss</groupId>
    <artifactId>aliyun-sdk-oss</artifactId>
</dependency>
```

##### 2.在相应的模块中创建配置文件，需要一个与主程序不一样的服务端口

```properties
#服务端口
server.port=8002
#服务名
spring.application.name=service-oss

#环境设置：dev、test、prod
spring.profiles.active=dev

#阿里云 OSS
#不同的服务器，地址不同
aliyun.oss.file.endpoint=oss-cn-beijing.aliyuncs.com
aliyun.oss.file.keyid=LTAI4GEbmrMAcdkd5ZKSrtQh
aliyun.oss.file.keysecret=VUiP4v51mMFBSosWs6zpqeLCVXaIq5
#bucket可以在控制台创建，也可以使用java代码创建
aliyun.oss.file.bucketname=myedu-guli
```

##### 3.配置模块里的主类,进行扫描，以及不使用数据库

```java
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@ComponentScan(basePackages = {"com.atwht"})
public class OssApplication {
    public static void main(String[] args) {
        SpringApplication.run(OssApplication.class,args);
    }
}
```

##### 4.创建一个utils读取配置文件中的内容，需要实现InitializingBean接口

```java
/**
 * 实现InitializingBean接口，在spring初始化后会做出相应的操作
 */
@Component
public class ConstantPropertiesUtils implements InitializingBean {
    //读取配置文件中的内容
    @Value("${aliyun.oss.file.endpoint}")
    private String endpoint;
    @Value("${aliyun.oss.file.keyid}")
    private String keyId;
    @Value("${aliyun.oss.file.keysecret}")
    private String keySecret;
    @Value("${aliyun.oss.file.bucketname}")
    private String bucketName;


    //定义公开常量
    public static String END_POINT;
    public static String ACCESS_KEY_ID;
    public static String ACCESS_KEY_SECRET;
    public static String BUCKET_NAME;

    @Override
    public void afterPropertiesSet() throws Exception {
        END_POINT = endpoint;
        ACCESS_KEY_ID = keyId;
        ACCESS_KEY_SECRET = keySecret;
        BUCKET_NAME = bucketName;
    }
}
```

##### 5.实现controller类，接收请求路径，MultipartFile获取文件

```java
@RestController
@RequestMapping("/eduoss/fileoss")
public class OssController {

    @Autowired
    private OssService ossService;

    //上传头像的方法
    @PostMapping
    public R uploadOssFile(MultipartFile multipartFile){
        //MultipartFile获取上传文件
        //返回路径
        String url = ossService.uploadFileAvatar(multipartFile);
        return R.ok().data("url",url);
    }
}
```

##### 6.创建service接口和实现类，在service类中实现文件的上传，需要使用之前的utils类中的内容

使用multipartFile可以获得文件的名称和输入流，==注意此处放入ossClient中的文件名要和返回的url中带有的文件名一样==

```java
@Service
public class OssServiceImpl implements OssService {
    @Override
    public String uploadFileAvatar(MultipartFile multipartFile){
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        String endpoint = ConstantPropertiesUtils.END_POINT;
        // 云账号AccessKey有所有API访问权限，建议遵循阿里云安全最佳实践，创建并使用RAM子账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建。
        String accessKeyId = ConstantPropertiesUtils.ACCESS_KEY_ID;
        String accessKeySecret = ConstantPropertiesUtils.ACCESS_KEY_SECRET;
        String bucketName = ConstantPropertiesUtils.BUCKET_NAME;

        try{
            // 创建OSSClient实例。
            OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

            // getInputStream获取上传文件输入流。
            InputStream inputStream = multipartFile.getInputStream();

            //获取文件名称
            String fileName = multipartFile.getOriginalFilename();
            fileName = fileName.replaceAll("\\\\","/");
            String[] files = fileName.split("/");
            String f = files[files.length-1];

            //在文件名里面添加随机的唯一的值
            //使用uuid
            String uuid = UUID.randomUUID().toString().replaceAll("-","");

            //把文件按照当前日期分类
            String datePath = new DateTime().toString("yyyy/MM/dd");
            f =datePath+"/"+ uuid + f;

            //调用oss方法实现上传
            //第一个参数 Bucket名称
            //第二个参数 上传到oss文件路径和文件名称
            //第三个参数 上传文件的输入流
            ossClient.putObject(bucketName,f,inputStream);

            // 关闭OSSClient。
            ossClient.shutdown();

            //返回上传后的阿里云oss路径
            //拼接
            String url = "https://"+bucketName+"."+endpoint+"/"+f;
            return url;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
```


### 注册使用

#### 1.引入依赖

```xml
<!--nacos服务注册-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
</dependency>
```

#### 2.在要注册的nacos的服务的配置文件中的application进行配置

```xml
#nacos服务地址
spring.cloud.nacos.discovery.server-addr=127.0.0.1:8848
```

#### 3.在启动类添加注解

``@EnableDiscoveryClient//nacos注册``
SDK：对api的一种封装，可以更方便的实现功能。

#### 步骤

##### 总体步骤

```go
1.根据视频id获取视频播放地址

创建初始化对象

创建获取视频地址request和response

向request对象里面设置视频id

调用初始化对象里面的方法，传递request，获取数据

```

##### 1.引入依赖

其中aliyun-java-sdk-vod依赖在中央仓库中不存在，需要先下载jar包再通过命令安装依赖。

``mvn install:install-file -DgroupId=com.aliyun -DartfactId=aliyun-sdk-vod-upload -Dversion=1.4.11 -Dpackaging=jar -Dfile=aliyun-java-vod-upload-1.4.11.jar``

```xml
<dependency>
    <groupId>com.aliyun</groupId>
    <artifactId>aliyun-java-sdk-core</artifactId>
    <version>4.5.1</version>
  </dependency>
  <dependency>
    <groupId>com.aliyun</groupId>
    <artifactId>aliyun-java-sdk-vod</artifactId>
    <version>2.15.11</version>
  </dependency>
  <dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.8.2</version>
  </dependency>
```

##### 2.初始化，得到DefaultAcsClient对象。后续功能都是使用对象中的方法

```java
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;

public static DefaultAcsClient initVodClient(String accessKeyId, String accessKeySecret) throws ClientException {
    String regionId = "cn-shanghai";  // 点播服务接入区域
    DefaultProfile profile = DefaultProfile.getProfile(regionId, accessKeyId, accessKeySecret);
    DefaultAcsClient client = new DefaultAcsClient(profile);
    return client;
}
```

##### 3.调用方法获取视频上传地址和凭证，根据视频的id获取.视频如果加密，得到地址无法播放，需要得到凭证

```java
//1.根据视频id获取视频播放地址
        //创建初始化对象
        DefaultAcsClient client = InitObject.initVodClient("LTAI4GEbmrMAcdkd5ZKSrtQh","VUiP4v51mMFBSosWs6zpqeLCVXaIq5");

        //创建获取视频地址request和response
        GetPlayInfoRequest request = new GetPlayInfoRequest();
        GetPlayInfoResponse response = new GetPlayInfoResponse();

        //向request对象里面设置视频id
        request.setVideoId("828c4816d30d48cbb9b1bdce5103afaf");

        //调用初始化对象里面的方法，传递request，获取数据
        response = client.getAcsResponse(request);

        List<GetPlayInfoResponse.PlayInfo> playInfoList = response.getPlayInfoList();
        //播放地址
        for(GetPlayInfoResponse.PlayInfo playInfo:playInfoList){
            System.out.println("PlayInfo.PlayURL = "+playInfo.getPlayURL());
        }
        //Base信息
        System.out.println("VideoBase.Title = "+response.getVideoBase().getTitle());
```

```java
public static void byId() throws Exception{
    //2.根据视频id获取视频播放凭证
    //创建初始化对象
    DefaultAcsClient client = InitObject.initVodClient("LTAI4GEbmrMAcdkd5ZKSrtQh","VUiP4v51mMFBSosWs6zpqeLCVXaIq5");

    //创建获取视频地址request和response
    GetVideoPlayAuthRequest request = new GetVideoPlayAuthRequest();
    GetVideoPlayAuthResponse response = new GetVideoPlayAuthResponse();

    //向request对象里面设置视频id
    request.setVideoId("1fdda77344b3413489f807bde79ded88");

    //调用初始化对象里面的方法，传递request，获取数据
    response = client.getAcsResponse(request);

    //获取凭证
    System.out.println("PlayAuth: "+response.getPlayAuth());
}
```

##### 4.视频的本地上传

```java
//上传视频
//四个参数
//1.id 2.密钥
//3.上传之后的文件的名称
//4.本地文件的路径和名称
String title = "";
String fileName = "";
UploadVideoRequest request = new UploadVideoRequest("LTAI4GEbmrMAcdkd5ZKSrtQh","VUiP4v51mMFBSosWs6zpqeLCVXaIq5", title, fileName);
/* 可指定分片上传时每个分片的大小，默认为2M字节 */
request.setPartSize(2 * 1024 * 1024L);
/* 可指定分片上传时的并发线程数，默认为1，(注：该配置会占用服务器CPU资源，需根据
服务器情况指定）*/
request.setTaskNum(1);

//设置完毕，最终上传
UploadVideoImpl uploader = new UploadVideoImpl();
UploadVideoResponse response = uploader.uploadVideo(request);

if (response.isSuccess()) {
    System.out.print("VideoId=" + response.getVideoId() + "\n");
} else {
    /* 如果设置回调URL无效，不影响视频上传，可以返回VideoId同时会返回错误码。其他
    情况上传失败时，VideoId为空，此时需要根据返回错误码分析具体错误原因 */
    System.out.print("VideoId=" + response.getVideoId() + "\n");
    System.out.print("ErrorCode=" + response.getCode() + "\n");
    System.out.print("ErrorMessage=" + response.getMessage() + "\n");
}
```

#### 在springboot中使用

##### 1.配置文件中写好配置

```properties
server.port=8003

spring.application.name=service-vod

spring.profiles.active=dev

aliyun.vod.keyid=LTAI4GEbmrMAcdkd5ZKSrtQh
aliyun.vod.file.keysecret=VUiP4v51mMFBSosWs6zpqeLCVXaIq5

#设置单个文件上传最大的大小，默认1MB
spring.servlet.multipart.max-file-size=1024MB
#设置总文件上传最大的大小，默认10MB
spring.servlet.multipart.max-request-size=1024MB
```

##### 2.写好controller类、service类等，这里使用的是流上传

```java
public class VodController {
    @Autowired
    private VodService vodService;

    //上传视频
    @PostMapping("uploadAlyVideo")
    public R uploadAlyVideo(MultipartFile file){
        String videoId = vodService.uploadVideoAly(file);
        return R.ok().data("videoId",videoId);
    }
}
```

```java
@Override
public String uploadVideoAly(MultipartFile file) {
    //流式上传
    //fileName：上传文件原始名称
    String fileName = file.getOriginalFilename();
    //截取名称
    String title = fileName.substring(fileName.lastIndexOf("\\")+1,fileName.lastIndexOf("."));
    //inputStream：上传文件输入流
    InputStream inputStream = null;
    try {
        inputStream = file.getInputStream();
        UploadStreamRequest request = new UploadStreamRequest(ConstantVodUtils.ACCESS_KEY_ID,ConstantVodUtils.ACCESS_KEY_SECRET,
                title, fileName, inputStream);

        UploadVideoImpl uploader = new UploadVideoImpl();
        UploadStreamResponse response = uploader.uploadStream(request);

        String videoId = null;

        if (response.isSuccess()) {
            videoId=response.getVideoId();
        } else { //如果设置回调URL无效，不影响视频上传，可以返回VideoId同时会返回错误码。其他情况上传失败时，VideoId为空，此时需要根据返回错误码分析具体错误原因
            videoId=response.getVideoId();
        }
        return videoId;
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}
```

##### 3.调用

##### 4.删除，使用初始化类

```java
public class InitVodClient {
    public static DefaultAcsClient initVodClient(String accessKeyId, String accessKeySecret) throws ClientException {
        String regionId = "cn-shanghai";  // 点播服务接入区域
        DefaultProfile profile = DefaultProfile.getProfile(regionId, accessKeyId, accessKeySecret);
        DefaultAcsClient client = new DefaultAcsClient(profile);
        return client;
    }
}
```

```java
//删除视频
@DeleteMapping("deleteAlyVideo/{id}")
public R deleteAlyVideo(@PathVariable String id){
    try {
        //1.初始化对象
        DefaultAcsClient client = InitVodClient.initVodClient(ConstantVodUtils.ACCESS_KEY_ID,ConstantVodUtils.ACCESS_KEY_SECRET);
        //2.初始化删除视频request对象
        DeleteVideoRequest request = new DeleteVideoRequest();
        //3.设置视频id
        request.setVideoIds(id);
        //4.调用方法删除视频
        client.getAcsResponse(request);
    } catch (ClientException e) {
        e.printStackTrace();
        throw new MyException(20001,"视频删除异常");
    }
    return R.ok();
}
```
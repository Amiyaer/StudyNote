### 调用Feign

#### 1.引入依赖

```xml
<!--服务调用-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
</dependency>
```

#### 2.在调用端的启动类上添加注解

```java
@EnableFeignClients
```

#### 3.在调用端创建interface，使用注解指定调用服务名称，定义调用的方法==完全路径==。这个接口不需要实现类，把远程的接口的实现调用过来。

```java
@FeignClient("service-vod")
@Component
public interface VodClient {
    //定义要调用的方法路径,要写完全路径
    //调用服务时@PathVariable一定要有指定的参数名称，否则报错
    //删除阿里云视频
    @DeleteMapping("/eduvod/video/deleteAlyVideo/{id}")
    public R deleteAlyVideo(@PathVariable("id") String id);
}
```

#### 4.实现代码，完成特定功能。

``vodClient.deleteAlyVideo(videoSourceId);``

```java
//删除小节,同时删除视频
@DeleteMapping("delete/{id}")
public R deleteVideo(@PathVariable String id){
    EduVideo video= videoService.getById(id);
    //查到当前小节的视频
    String videoSourceId = video.getVideoSourceId();
    //判断当前小节是否有视频
    if(!StringUtils.isEmpty(videoSourceId)){
        vodClient.deleteAlyVideo(videoSourceId);
    }
    videoService.removeById(id);
    return R.ok();
}
```



### Feign的基础上整合Hystrix

#### 1.引入依赖 

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-ribbon</artifactId>
</dependency>

<!--hystrix依赖，主要是用  @HystrixCommand -->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
</dependency>
```

#### 2.在配置文件中配置，在调用端配置

```properties
#开启熔断机制
feign.hystrix.enabled=true

# 设置hystrix超时时间，默认1000ms
hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds=6000
```

#### 3.创建相应调用端Interface的实现类并实现方法(这个类的方法在出错时才会执行)，Interface在之前使用Feign的时候创建过了

```java
@Component
public class VodClientFeignImpl implements VodClient {
    //出错之后才会执行

    @Override
    public R deleteAlyVideo(String id) {
        return R.error().message("删除视频熔断。。");
    }

    @Override
    public R deleteBatch(List<String> videoList) {
        return R.error().message("删除多个视频熔断。。");
    }
}
```

#### 4.在原来的Interface中的注解上加一条属性fallback，值等于实现类class

```java
@FeignClient(name = "service-vod",fallback = VodClientFeignImpl.class)
```

#### 5.使用

```java
R result = vodClient.deleteAlyVideo(videoSourceId);
if(result.getCode()==20001){
    throw new MyException(20001,"删除video失败了");
}
```


### 操纵

#### 1.引入依赖

还需要poi依赖(2.1.1一定要对于poi的3.1.7版本)

```xml
<dependency>    
    <groupId>com.alibaba</groupId>    
    <artifactId>easyexcel</artifactId>    
    <version>2.1.1</version>
</dependency>
```

#### 2.1写操作

##### 2.1.1创建实体类，跟excel对应

```java
@Data
public class DemoData {
    //设置excel表头的注解
    @ExcelProperty(value = "学生编号",index = 0)
    private Integer sno;
    @ExcelProperty(value = "学生姓名",index = 1)
    private String sname;
}
```

##### 2.1.2主方法实现

```java
	//创建方法返回数据集合
    private static List<DemoData> getData(){
        List<DemoData> list = new ArrayList<>();
        for(int i = 0;i < 10;i++){
            DemoData data = new DemoData();
            data.setSno(i);
            data.setSname("wht"+i);
            list.add(data);
        }
        return list;
    }

    public static void main(String[] args) {
        //实现写操作
        //1.设置写入文件地址和excel文件名称
        String filename = "E:\\write.xls";

        //2.调用实现写操作
        //第一个参数，文件路径名称
        //第二个参数，实体类class
        EasyExcel.write(filename,DemoData.class).sheet("学生列表").doWrite(getData());
    }
```

#### 2.2读操作

##### 2.2.1创建实体类，跟excel对应

##### 2.2.2创建监听器，用于逐行读取

```java
public class ExcelListener extends AnalysisEventListener<DemoData> {
    //一行一行读取
    @Override
    public void invoke(DemoData o, AnalysisContext analysisContext) {
        System.out.println("****"+o);
    }

    //读取表头
    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        System.out.println("表头"+headMap);
    }

    //读取完成之后
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }
}
```

##### 2.2.3主方法实现

```java
public static void main(String[] args) {
        //1.设置写入文件地址和excel文件名称
        String filename = "E:\\write.xls";
    
        //2.调用实现读操作
        EasyExcel.read(filename,DemoData.class,new ExcelListener()).sheet().doRead();
}
```






### 使用步骤

#### 1.在nginx.conf中配置相关信息

##### （1）修改nginx默认端口

```xml
server {
        listen 81;
}
```

##### （2）配置转发规则(注意要写在http{}里面)

```xml
server {
        listen       9001;
        server_name  localhost;

        location ~ /eduservice/ {
            proxy_pass http://localhost:8001;
        }
		location ~ /eduoss/ {
            proxy_pass http://localhost:8002;
        }
    }
```

##### (3)修改前端地址为nginx地址

```javascript
module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  BASE_API: '"http://localhost:9001"',
})
```

##### (4)重新启动nginx


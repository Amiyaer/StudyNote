#### 乐观锁

一个解决问题的方式。用来解决==丢失更新==的问题。

丢失更新：事务中写的问题。多个人同时修改同一条记录，最后提交的把之前的提交数据给覆盖。

解决方案：悲观锁和乐观锁

**悲观锁**：只能一个人对数据进行操作(串行)。

**乐观锁**：使用``version``给数据库加上版本。读取数据时会将版本号也一起读取过来。修改的时候比较数据库==现在的版本==和自己原先读取到的版本，如果版本一致才能够进行修改，修改后会将数据库中的版本也进行==更新(+1)==。``简单来说就是第一个人修改以后其他的人就不能够再次进行修改了``。

乐观锁的使用顺序：在数据库中添加version属性---->在实体类中添加相应的属性并打上@Version和@TableField注解---->在配置类中配置乐观锁插件---->使用(先查询selectById再修改updateById)



#### crud

##### 分页查询

类似于PageHelper。

第一步：配置分页插件

第二步：编写分页的代码(new page对象，传入两个参数：当前页和每页记录数)

第三步：调用方法实现分页查询

```java
@Test
    void pageSelected(){
        //分页查询
        //1.创建page对象
        //传入两个参数：当前页和每页记录数
        Page<User> page = new Page<>(1,3);
        //调用分页查询方法
        //底层会把我们分页的所有数据封装到配置对象
        userMapper.selectPage(page,null);
    }
```

底层封装的数据的获取

page.getRecords()每页数据集合

page.getCurrent()当前页

page.getPages()总页数

page.getSize()每页显示记录数

page.getTotal()总记录数

page.hasNext()是否有下一页

page.hasPrevious()是否有上一页



##### 逻辑删除

第一步：表和实体类添加**删除**标签位，属性上添加``@TableLogic``注解

第二步：配置逻辑删除插件

这时再使用删除功能，实现的就是逻辑删除了，不会真正的删除数据，只会把删除的标识符由未删除改为已删除。



##### 条件查询

一般使用QueryWrapper来构建条件

第一步：创建QueryWrapper对象

第二步：调用里面的 方法实现各种查询

```java
//条件查询
@Test
void selectQuery(){
    QueryWrapper<User> queryWrapper = new QueryWrapper<>();
    //设置条件
    //1.ge大于等于,gt小于等于,le大于,lt小于
    //age大于等于30的记录
    //参数：属性名，属性值
    //between的参数有开始值和结束值在内的三个参数
    queryWrapper.ge("age",30);
    //2.eq等于,ne不等于
    queryWrapper.eq("name","cnm");
    //3.like模糊查询,包含
    queryWrapper.like("name","c");
    //4.orderByDesc,orderByAsc排序
    queryWrapper.orderByDesc("id");
    //5.last向最后拼接一条SQl语句
    //6.select指定要查询的列
    queryWrapper.select("id","name");
    List<User> users = userMapper.selectList(queryWrapper);
    System.out.println(users);
}
```

##### 条件组合(分页)查询

把所有的条件封装到一个对象中，把对象传入到接口中

1.创建包，创建TeacherQuery查询对象(具体的条件值约束)

```java
@Data
public class TeacherQuery implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "教师名称,模糊查询")
    private String name;

    @ApiModelProperty(value = "头衔 1高级讲师 2首席讲师")
    private Integer level;

    @ApiModelProperty(value = "查询开始时间", example = "2019-01-01 10:10:10")
    private String begin;//注意，这里使用的是String类型，前端传过来的数据无需进行类型转换

    @ApiModelProperty(value = "查询结束时间", example = "2019-12-01 10:10:10")
    private String end;
}

```

2.在controller中作为参数引入并使用

```java
//条件组合分页查询
    @PostMapping("pageTeacherCondition/{current}/{size}")
    public R pageTeacherCondition(@PathVariable Long current,
                                  @PathVariable Long size,
                                  //RequestBody使用json传递数据到前端中去
                                  //使用RequestBody需要把请求变为post
                                  //required = false参数可以为空
                                  @RequestBody(required = false) TeacherQuery teacherQuery){
        //page对象
        Page<EduTeacher> teachers = new Page(current,size);
        //条件对象
        QueryWrapper<EduTeacher> queryWrapper = new QueryWrapper<>();
        //条件组合查询
        String begin = teacherQuery.getBegin();
        String end = teacherQuery.getEnd();
        Integer level = teacherQuery.getLevel();
        String name = teacherQuery.getName();
        //判断条件值是否为空，如果不为空需要拼接条件
        if(!StringUtils.isEmpty(name)){
            queryWrapper.like("name",name);
        }
        if(!StringUtils.isEmpty(level)){
            queryWrapper.eq("level",level);
        }
        if(!StringUtils.isEmpty(begin)){
            queryWrapper.ge("gmt_create",begin);
        }
        if(!StringUtils.isEmpty(end)){
            queryWrapper.ne("gmt_modified",end);
        }
        eduTeacherService.page(teachers,queryWrapper);
        return R.ok().data("total",teachers.getTotal()).data("rows",teachers.getRecords());
    }
```

``@RequestBody``，此注解表示将此注解标注的属性以JSON数据的格式返回到前端去。使用此注解的时候，接收方法只能是Post，即``@PostMapper``。


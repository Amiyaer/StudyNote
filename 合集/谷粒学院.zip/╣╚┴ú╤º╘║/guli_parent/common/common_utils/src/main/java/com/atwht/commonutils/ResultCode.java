package com.atwht.commonutils;

public interface ResultCode {
    //成功和失败的状态码
    public static Integer SUCCESS = 20000;
    public static Integer ERROR = 20001;
}

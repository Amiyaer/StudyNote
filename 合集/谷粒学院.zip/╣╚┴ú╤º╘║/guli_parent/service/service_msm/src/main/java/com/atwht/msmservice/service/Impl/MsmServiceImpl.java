package com.atwht.msmservice.service.Impl;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.atwht.msmservice.service.MsmService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Map;

@Service
public class MsmServiceImpl implements MsmService {
    //发送短信的方法
    @Override
    public boolean send(Map<String, Object> param, String phoneNum) {
        if(StringUtils.isEmpty(phoneNum)) return false;

        DefaultProfile profile =
                DefaultProfile.getProfile("default", "LTAI4GEbmrMAcdkd5ZKSrtQh", "VUiP4v51mMFBSosWs6zpqeLCVXaIq5");
        IAcsClient client = new DefaultAcsClient(profile);

        //设置相关固定参数
        CommonRequest request = new CommonRequest();
        //提交方式
        request.setMethod(MethodType.POST);
        //请求哪里的方法
        request.setDomain("dysmsapi.aliyuncs.com");
        //版本号
        request.setVersion("2017-05-25");
        //请求那个方法
        request.setAction("SendSms");

        //设置发送的相关参数
        //手机号
        request.putQueryParameter("PhoneNumbers",phoneNum);
        //签名
        request.putQueryParameter("SignName","自己的名称");
        //模板
        request.putQueryParameter("TemplateCode","自己的名称");
        //验证码
        request.putQueryParameter("TemplateParam", JSONObject.toJSONString(param));

        try{
            //最终发送
            CommonResponse response = client.getCommonResponse(request);
            boolean success = response.getHttpResponse().isSuccess();
            return success;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
}

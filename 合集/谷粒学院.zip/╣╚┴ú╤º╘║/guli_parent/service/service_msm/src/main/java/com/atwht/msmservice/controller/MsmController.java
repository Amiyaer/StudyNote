package com.atwht.msmservice.controller;

import com.atwht.commonutils.R;
import com.atwht.msmservice.service.MsmService;
import com.atwht.msmservice.utils.RandomUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/edumsm/msm")
@CrossOrigin
public class MsmController {
    @Autowired
    private MsmService msmService;

    @Autowired
    private RedisTemplate<String,String> redisTemplate;

    //发送短信的方法
    @GetMapping("send/{phoneNum}")
    public R sendMsm(@PathVariable String phoneNum){
        //1.从redis中取验证码，取得到就直接返回
        String codes = redisTemplate.opsForValue().get(phoneNum);
        if(!StringUtils.isEmpty(codes)){
            return R.ok();
        }

        //2.没有获取到验证码，自己进行发送
        //验证码的值需要自己生成，阿里云仅仅起到传递功能
        String code = RandomUtil.getFourBitRandom();
        //把生成的验证码放进一个map中传过去
        Map<String,Object> param = new HashMap<>();
        param.put("code",code);
        //调用service发送短信
        boolean isSend = msmService.send(param,phoneNum);
        if(isSend){
            //发送成功，把发送成功的验证码放到redis里面
            //设置有效时间5分钟
            redisTemplate.opsForValue().set(phoneNum,code,5, TimeUnit.MINUTES);
            return R.ok();
        }
        return R.error().message("短信发送失败");
    }
}

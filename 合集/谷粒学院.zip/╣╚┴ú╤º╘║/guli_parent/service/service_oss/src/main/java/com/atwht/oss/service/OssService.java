package com.atwht.oss.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;

public interface OssService {
    //上传头像的方法
    String uploadFileAvatar(MultipartFile multipartFile) throws FileNotFoundException;
}

package com.atwht.oss.controller;

import com.atwht.commonutils.R;
import com.atwht.oss.service.OssService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;

@RestController
@RequestMapping("/eduoss/fileoss")
@CrossOrigin
public class OssController {

    @Autowired
    private OssService ossService;

    //上传头像的方法
    @PostMapping
    public R uploadOssFile(@RequestParam("file") MultipartFile multipartFile){
        //MultipartFile获取上传文件
        //返回路径
        try {
            String url = ossService.uploadFileAvatar(multipartFile);
            return R.ok().data("url",url);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return R.error();
        }
    }
}

package com.atwht.oss.service.impl;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.atwht.oss.service.OssService;
import com.atwht.oss.utils.ConstantPropertiesUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.UUID;

@Service
public class OssServiceImpl implements OssService {
    @Override
    public String uploadFileAvatar(MultipartFile multipartFile){
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        String endpoint = ConstantPropertiesUtils.END_POINT;
        // 云账号AccessKey有所有API访问权限，建议遵循阿里云安全最佳实践，创建并使用RAM子账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建。
        String accessKeyId = ConstantPropertiesUtils.ACCESS_KEY_ID;
        String accessKeySecret = ConstantPropertiesUtils.ACCESS_KEY_SECRET;
        String bucketName = ConstantPropertiesUtils.BUCKET_NAME;

        try{
            // 创建OSSClient实例。
            OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

            // getInputStream获取上传文件输入流。
            InputStream inputStream = multipartFile.getInputStream();

            //获取文件名称
            String fileName = multipartFile.getOriginalFilename();
            fileName = fileName.replaceAll("\\\\","/");
            String[] files = fileName.split("/");
            String f = files[files.length-1];

            //在文件名里面添加随机的唯一的值
            //使用uuid
            String uuid = UUID.randomUUID().toString().replaceAll("-","");

            //把文件按照当前日期分类
            String datePath = new DateTime().toString("yyyy/MM/dd");
            f =datePath+"/"+ uuid + f;

            //调用oss方法实现上传
            //第一个参数 Bucket名称
            //第二个参数 上传到oss文件路径和文件名称
            //第三个参数 上传文件的输入流
            ossClient.putObject(bucketName,f,inputStream);

            // 关闭OSSClient。
            ossClient.shutdown();

            //返回上传后的阿里云oss路径
            //拼接
            String url = "https://"+bucketName+"."+endpoint+"/"+f;
            return url;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}

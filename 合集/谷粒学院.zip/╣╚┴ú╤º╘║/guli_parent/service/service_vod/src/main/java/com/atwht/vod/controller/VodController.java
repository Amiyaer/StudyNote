package com.atwht.vod.controller;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.vod.model.v20170321.DeleteVideoRequest;
import com.atwht.commonutils.R;
import com.atwht.exceptionhandler.MyException;
import com.atwht.vod.service.VodService;
import com.atwht.vod.utils.ConstantVodUtils;
import com.atwht.vod.utils.InitVodClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/eduvod/video")
@CrossOrigin
public class VodController {
    @Autowired
    private VodService vodService;

    //上传视频
    @PostMapping("uploadAlyVideo")
    public R uploadAlyVideo(MultipartFile file){
        String videoId = vodService.uploadVideoAly(file);
        return R.ok().data("videoId",videoId);
    }

    //删除视频
    @DeleteMapping("deleteAlyVideo/{id}")
    public R deleteAlyVideo(@PathVariable String id){
        try {
            //1.初始化对象
            DefaultAcsClient client = InitVodClient.initVodClient(ConstantVodUtils.ACCESS_KEY_ID,ConstantVodUtils.ACCESS_KEY_SECRET);
            //2.初始化删除视频request对象
            DeleteVideoRequest request = new DeleteVideoRequest();
            //3.设置视频id
            request.setVideoIds(id);
            //4.调用方法删除视频
            client.getAcsResponse(request);
        } catch (ClientException e) {
            e.printStackTrace();
            throw new MyException(20001,"视频删除异常");
        }
        return R.ok();
    }

    //删除多个视频
    @DeleteMapping("deleteBatch")
    public R deleteBatch(@RequestParam("videoList") List<String> videoList){
        vodService.removeMultyAlyVideo(videoList);
        return R.ok();
    }
}

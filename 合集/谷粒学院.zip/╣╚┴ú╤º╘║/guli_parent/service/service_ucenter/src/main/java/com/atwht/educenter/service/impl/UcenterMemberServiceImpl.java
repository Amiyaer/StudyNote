package com.atwht.educenter.service.impl;

import com.atwht.commonutils.JwtUtils;
import com.atwht.educenter.entity.UcenterMember;
import com.atwht.educenter.entity.vo.RegisterVo;
import com.atwht.educenter.mapper.UcenterMemberMapper;
import com.atwht.educenter.service.UcenterMemberService;
import com.atwht.educenter.utils.MD5;
import com.atwht.exceptionhandler.MyException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2021-01-09
 */
@Service
public class UcenterMemberServiceImpl extends ServiceImpl<UcenterMemberMapper, UcenterMember> implements UcenterMemberService {

    @Override
    public String login(UcenterMember member) {
        String mobile = member.getMobile();
        String password = member.getPassword();

        if(StringUtils.isEmpty(mobile) || StringUtils.isEmpty(password)) throw new MyException(20001,"手机号或密码为空");

        QueryWrapper<UcenterMember> wrapper = new QueryWrapper<>();
        wrapper.eq("mobile",mobile);
        UcenterMember ucenterMember = baseMapper.selectOne(wrapper);

        if(ucenterMember == null) throw new MyException(20001,"查不到登录用户");

        //数据库中的密码是进行过加密的，需要先把输入的密码进行加密再进行比较
        //加密方式：MD5加密
        if(!MD5.encrypt(password).equals(ucenterMember.getPassword())) throw new MyException(20001,"密码错误");

        if(ucenterMember.getIsDisabled()) throw new MyException(20001,"用户被禁用");

        //登陆成功，返回token
        String jwtToken = JwtUtils.getJwtToken(ucenterMember.getId(), ucenterMember.getNickname());
        return jwtToken;
    }

    @Override
    public void register(RegisterVo registerVo) {
        String code = registerVo.getCode();
        String mobile = registerVo.getMobile();
        String nickname = registerVo.getNickname();
        String password = registerVo.getPassword();

        if(StringUtils.isEmpty(code) || StringUtils.isEmpty(mobile)
        || StringUtils.isEmpty(nickname) || StringUtils.isEmpty(password)) throw new MyException(20001,"vo用户为空");
    }
}

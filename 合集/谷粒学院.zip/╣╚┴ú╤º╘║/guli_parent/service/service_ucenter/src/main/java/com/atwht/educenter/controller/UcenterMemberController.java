package com.atwht.educenter.controller;


import com.atwht.commonutils.R;
import com.atwht.educenter.entity.UcenterMember;
import com.atwht.educenter.entity.vo.RegisterVo;
import com.atwht.educenter.service.UcenterMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2021-01-09
 */
@RestController
@RequestMapping("/educenter/member")
@CrossOrigin
public class UcenterMemberController {
    @Autowired
    private UcenterMemberService memberService;

    //登录的方法
    @PostMapping("login")
    public R loginUser(@RequestBody UcenterMember member){
        //调用service方法登录
        //返回token值
        String token = memberService.login(member);
        return R.ok().data("token",token);
    }

    //注册的方法
    @PostMapping("register")
    public R registerUser(@RequestBody RegisterVo registerVo){
        memberService.register(registerVo);
        return R.ok();
    }

}


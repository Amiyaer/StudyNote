package com.atwht.educenter;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.atwht"})
@MapperScan("com.atwht.educenter.mapper")
public class CenterApplication {
    public static void main(String[] args) {
        SpringApplication.run(CenterApplication.class);
    }
}

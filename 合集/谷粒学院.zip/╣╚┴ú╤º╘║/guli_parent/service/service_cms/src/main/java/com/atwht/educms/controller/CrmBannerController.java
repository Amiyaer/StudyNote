package com.atwht.educms.controller;


import com.atwht.commonutils.R;
import com.atwht.educms.entity.CrmBanner;
import com.atwht.educms.service.CrmBannerService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 首页banner表 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2020-12-25
 */
@RestController
@RequestMapping("/educms/banner")
@CrossOrigin
public class CrmBannerController {
    @Autowired
    private CrmBannerService bannerService;
    //普通用户前台调用
    //查全部
    @GetMapping("getAllBanner")
    public R getAllBanner(){
        List<CrmBanner> bannerList = bannerService.selectAllBanner();
        return R.ok().data("bannerList",bannerList);
    }
    //===========================================================================================================================================
    //管理员后台调用
    //分页查询
    @GetMapping("pageBanner/{page}/{limit}")
    public R pageBanner(@PathVariable Long page,@PathVariable Long limit){
        Page<CrmBanner> bannerPage = new Page<>(page,limit);
        bannerService.page(bannerPage,null);
        return R.ok().data("page",bannerPage.getRecords()).data("total",bannerPage.getTotal());
    }

    //添加
    @PostMapping("addBanner")
    public R addBanner(@RequestBody CrmBanner banner){
        bannerService.save(banner);
        return R.ok();
    }

    //根据id查询
    @GetMapping("getById/{id}")
    public R getById(@PathVariable String id){
        CrmBanner banner = bannerService.getById(id);
        return R.ok().data("banner",banner);
    }

    //修改
    @PostMapping("updateBanner")
    public R updateBanner(@RequestBody CrmBanner banner){
        bannerService.updateById(banner);
        return R.ok();
    }

    //删除
    @DeleteMapping("delete/{id}")
    public R delete(@PathVariable String id){
        bannerService.removeById(id);
        return R.ok();
    }
}


package com.atwht;

import com.alibaba.excel.EasyExcel;

import java.util.ArrayList;
import java.util.List;

public class TestEassyExcxl {
    //创建方法返回数据集合
    private static List<DemoData> getData(){
        List<DemoData> list = new ArrayList<>();
        for(int i = 0;i < 10;i++){
            DemoData data = new DemoData();
            data.setSno(i);
            data.setSname("wht"+i);
            list.add(data);
        }
        return list;
    }

    public static void main(String[] args) {
        //实现写操作
        //1.设置写入文件地址和excel文件名称
        String filename = "E:\\write.xls";

        //2.调用实现写操作
        //第一个参数，文件路径名称
        //第二个参数，实体类class
        //EasyExcel.write(filename,DemoData.class).sheet("学生列表").doWrite(getData());

        //3.调用实现读操作
        EasyExcel.read(filename,DemoData.class,new ExcelListener()).sheet().doRead();
    }
}

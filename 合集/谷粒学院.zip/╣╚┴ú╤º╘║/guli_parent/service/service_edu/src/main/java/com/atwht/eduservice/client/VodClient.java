package com.atwht.eduservice.client;

import com.atwht.commonutils.R;
import com.atwht.eduservice.client.impl.VodClientFeignImpl;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "service-vod",fallback = VodClientFeignImpl.class)
@Component
public interface VodClient {
    //定义要调用的方法路径,要写完全路径

    //删除阿里云视频
    //调用服务时@PathVariable一定要有指定的参数名称，否则报错
    @DeleteMapping("/eduvod/video/deleteAlyVideo/{id}")
    public R deleteAlyVideo(@PathVariable("id") String id);

    //删除多个视频
    @DeleteMapping("/eduvod/video/deleteBatch")
    public R deleteBatch(@RequestParam("videoList") List<String> videoList);
}

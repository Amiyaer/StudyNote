package com.atwht.eduservice.controller;


import com.atwht.commonutils.R;
import com.atwht.eduservice.client.VodClient;
import com.atwht.eduservice.entity.EduVideo;
import com.atwht.eduservice.service.EduVideoService;
import com.atwht.exceptionhandler.MyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 课程视频 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
@RestController
@RequestMapping("/eduservice/video")
@CrossOrigin
public class EduVideoController {
    @Autowired
    private EduVideoService videoService;
    @Autowired
    private VodClient vodClient;

    //添加小节
    @PostMapping("addVideo")
    public R addVideo(@RequestBody EduVideo eduVideo){
        videoService.save(eduVideo);
        return R.ok();
    }

    //删除小节,同时删除视频
    @DeleteMapping("delete/{id}")
    public R deleteVideo(@PathVariable String id){
        EduVideo video= videoService.getById(id);
        //查到当前小节的视频
        String videoSourceId = video.getVideoSourceId();
        //判断当前小节是否有视频
        if(!StringUtils.isEmpty(videoSourceId)){
            R result = vodClient.deleteAlyVideo(videoSourceId);
            if(result.getCode()==20001){
                throw new MyException(20001,"删除video失败了");
            }
        }
        videoService.removeById(id);
        return R.ok();
    }

    //修改小节
    @PostMapping("updateVideo")
    public R updateVideo(@RequestBody EduVideo video){
        videoService.updateById(video);
        return R.ok();
    }

    //根据id查询
    @GetMapping("getVideoById/{id}")
    public R getVideoById(@PathVariable String id){
        EduVideo video = videoService.getById(id);
        return R.ok().data("video",video);
    }
}


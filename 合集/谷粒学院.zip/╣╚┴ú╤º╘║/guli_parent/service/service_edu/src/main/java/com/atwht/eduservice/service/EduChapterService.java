package com.atwht.eduservice.service;

import com.atwht.eduservice.entity.EduChapter;
import com.atwht.eduservice.entity.chapter.ChapterVo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
public interface EduChapterService extends IService<EduChapter> {
    //查询所有章节
    List<ChapterVo> getChapterVideoById(String courseId);
    //删除章节
    boolean deleteChapter(String chapterId);

    void removeByCourseId(String courseId);
}

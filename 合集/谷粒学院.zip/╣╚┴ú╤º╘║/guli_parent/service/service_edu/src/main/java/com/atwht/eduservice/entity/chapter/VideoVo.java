package com.atwht.eduservice.entity.chapter;

import lombok.Data;

@Data
public class VideoVo {
    private String id;

    private String title;
}

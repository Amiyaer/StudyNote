package com.atwht.eduservice.controller;


import com.atwht.commonutils.R;
import com.atwht.eduservice.entity.EduCourse;
import com.atwht.eduservice.entity.vo.CourseInfoVo;
import com.atwht.eduservice.entity.vo.CoursePublishVo;
import com.atwht.eduservice.entity.vo.CourseQuery;
import com.atwht.eduservice.service.EduChapterService;
import com.atwht.eduservice.service.EduCourseDescriptionService;
import com.atwht.eduservice.service.EduCourseService;
import com.atwht.eduservice.service.EduVideoService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 课程 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
@RestController
@RequestMapping("/eduservice/course")
@CrossOrigin
public class EduCourseController {
    @Autowired
    private EduCourseService eduCourseService;

    //无条件查全部
    @GetMapping("list")
    public R list(){
        List<EduCourse> courses = eduCourseService.list(null);
        return R.ok().data("courses",courses);
    }

    //条件组合分页查询
    @PostMapping("pageCourseCondition/{current}/{size}")
    public R pageCourseCondition(@PathVariable int current,
                                  @PathVariable int size,
                                  //RequestBody使用json传递数据到前端中去
                                  //使用RequestBody需要把请求变为post
                                  //required = false参数可以为空
                                  @RequestBody(required = false) CourseQuery courseQuery) throws Exception{
        //page对象
        Page<EduCourse> courses = new Page(current,size);
        //条件对象
        QueryWrapper<EduCourse> queryWrapper = new QueryWrapper<>();
        //根据添加时间排序
        queryWrapper.orderByDesc("gmt_create");
        //条件组合查询
        String begin = courseQuery.getBegin();
        String end = courseQuery.getEnd();
        String status = courseQuery.getStatus();
        String title = courseQuery.getTitle();
        //判断条件值是否为空，如果不为空需要拼接条件
        if(courseQuery != null){
            if(!StringUtils.isEmpty(title)){
                queryWrapper.like("title",title);
            }
            if(!StringUtils.isEmpty(status)){
                queryWrapper.eq("status",status);
            }
            if(!StringUtils.isEmpty(begin)){
                queryWrapper.ge("gmt_create",begin);
            }
            if(!StringUtils.isEmpty(end)){
                queryWrapper.le("gmt_modified",end);
            }
        }
        eduCourseService.page(courses,queryWrapper);
        if(courses.getRecords() != null){
            return R.ok().data("total",courses.getTotal()).data("courses",courses.getRecords());
        }
        return R.ok().data("total",0).data("courses",null);
    }

    //添加课程信息
    @PostMapping("/addCourseInfo")
    public R addCourseInfo(@RequestBody CourseInfoVo courseInfoVo){
        String courseId = eduCourseService.saveCourseInfo(courseInfoVo);
        return R.ok().data("courseId",courseId);
    }

    //根据id查询
    @GetMapping("/getCourseInfo/{courseId}")
    public R getCourseInfo(@PathVariable String courseId){
        CourseInfoVo courseInfoVo = eduCourseService.getCourseInfo(courseId);
        return R.ok().data("courseInfoVo",courseInfoVo);
    }

    //修改课程信息
    @PostMapping("/updateCourseInfo")
    public R updateCourseInfo(@RequestBody CourseInfoVo courseInfoVo){
        eduCourseService.updateCourseInfo(courseInfoVo);
        return R.ok();
    }

    //课程最终信息查询
    @GetMapping("getPublishCourseInfo/{id}")
    public R getPublishCourseInfo(@PathVariable String id){
        CoursePublishVo coursePublishVo = eduCourseService.getPublishInfo(id);
        return R.ok().data("coursePublish",coursePublishVo);
    }

    //课程最终发布
    @PostMapping("publishCourse/{id}")
    public R publishCourse(@PathVariable String id){
        EduCourse eduCourse = new EduCourse();
        eduCourse.setId(id);
        eduCourse.setStatus("Normal");
        eduCourseService.updateById(eduCourse);
        return R.ok();
    }

    //课程删除
    @DeleteMapping("deleteCourse/{id}")
    public R deleteCourse(@PathVariable String id){
        eduCourseService.deleteById(id);
        return R.ok();
    }
}


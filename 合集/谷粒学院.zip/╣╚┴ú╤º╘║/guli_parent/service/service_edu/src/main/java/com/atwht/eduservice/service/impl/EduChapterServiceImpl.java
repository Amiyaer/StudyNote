package com.atwht.eduservice.service.impl;

import com.atwht.eduservice.entity.EduChapter;
import com.atwht.eduservice.entity.EduVideo;
import com.atwht.eduservice.entity.chapter.ChapterVo;
import com.atwht.eduservice.entity.chapter.VideoVo;
import com.atwht.eduservice.mapper.EduChapterMapper;
import com.atwht.eduservice.service.EduChapterService;
import com.atwht.eduservice.service.EduVideoService;
import com.atwht.exceptionhandler.MyException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
@Service
public class EduChapterServiceImpl extends ServiceImpl<EduChapterMapper, EduChapter> implements EduChapterService {
    @Autowired
    private EduVideoService videoService;

    //查询课程大纲列表
    @Override
    public List<ChapterVo> getChapterVideoById(String courseId) {
        //查询所有章节
        QueryWrapper<EduChapter> wrapper = new QueryWrapper<>();
        wrapper.eq("course_id",courseId);
        List<EduChapter> eduChapterList = baseMapper.selectList(wrapper);
        //查询所有小节
        QueryWrapper<EduVideo> wrapperVideo = new QueryWrapper<>();
        wrapperVideo.eq("course_id",courseId);
        List<EduVideo> eduVideoList = videoService.list(wrapperVideo);
        //封装数据返回
        List<ChapterVo> chapterVoList = new ArrayList<>();
        for(EduChapter e : eduChapterList){
            ChapterVo chapterVo = new ChapterVo();
            BeanUtils.copyProperties(e,chapterVo);
            List<VideoVo> videoVoList = new ArrayList<>();
            for(EduVideo v:eduVideoList){
                VideoVo videoVo = new VideoVo();
                BeanUtils.copyProperties(v,videoVo);
                if(v.getChapterId().equals(e.getId())){
                    videoVoList.add(videoVo);
                }
            }
            chapterVo.setChildren(videoVoList);
            chapterVoList.add(chapterVo);
        }
        return chapterVoList;
    }

    //删除章节
    @Override
    public boolean deleteChapter(String chapterId) {
        //查询小节，如果查到有小节，不进行删除
        QueryWrapper<EduVideo> wrapper = new QueryWrapper<>();
        wrapper.eq("chapter_id",chapterId);
        int count = videoService.count(wrapper);
        if(count>0){
            throw new MyException(20001,"有小节不能进行删除！");
        }else{
            int result = baseMapper.deleteById(chapterId);
            return result>0;
        }
    }

    //根据课程id删除
    @Override
    public void removeByCourseId(String courseId) {
        QueryWrapper<EduChapter> wrapper = new QueryWrapper<>();
        wrapper.eq("course_id",courseId);
        baseMapper.delete(wrapper);
    }
}

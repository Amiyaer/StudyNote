package com.atwht.eduservice.controller;


import com.atwht.commonutils.R;
import com.atwht.eduservice.entity.EduTeacher;
import com.atwht.eduservice.entity.vo.TeacherQuery;
import com.atwht.eduservice.service.EduTeacherService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 讲师 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2020-11-19
 */
@RestController
@RequestMapping("/eduservice/teacher")
@CrossOrigin//解决跨域问题
public class EduTeacherController{
    @Autowired
    EduTeacherService eduTeacherService;

    //查全部
    @GetMapping("findAll")
    public R findAllTeacher(){
        List<EduTeacher> teachers = eduTeacherService.list(null);
        return R.ok().data("items",teachers);
    }

    //逻辑删除
    @DeleteMapping("delete/{id}")
    public R removeTeacher(@PathVariable String id){
        boolean flag = eduTeacherService.removeById(id);
        if(flag){
            return R.ok();
        }else {
            return R.error();
        }
    }

    //分页查询
    @GetMapping("teacherPage/{current}/{size}")
    public R pageListTeacher(@PathVariable Long current,
                             @PathVariable Long size){
        Page<EduTeacher> teachers = new Page(current,size);
        eduTeacherService.page(teachers,null);
        return R.ok().data("total",teachers.getTotal()).data("rows",teachers.getRecords());
    }

    //条件组合分页查询
    @PostMapping("pageTeacherCondition/{current}/{size}")
    public R pageTeacherCondition(@PathVariable Long current,
                                  @PathVariable Long size,
                                  //RequestBody使用json传递数据到前端中去
                                  //使用RequestBody需要把请求变为post
                                  //required = false参数可以为空
                                  @RequestBody(required = false) TeacherQuery teacherQuery) throws Exception{
        //page对象
        Page<EduTeacher> teachers = new Page(current,size);
        //条件对象
        QueryWrapper<EduTeacher> queryWrapper = new QueryWrapper<>();
        //根据添加时间排序
        queryWrapper.orderByDesc("gmt_create");
        //条件组合查询
        String begin = teacherQuery.getBegin();
        String end = teacherQuery.getEnd();
        Integer level = teacherQuery.getLevel();
        String name = teacherQuery.getName();
        //判断条件值是否为空，如果不为空需要拼接条件
        if(teacherQuery != null){
            if(!StringUtils.isEmpty(name)){
                queryWrapper.like("name",name);
            }
            if(!StringUtils.isEmpty(level)){
                queryWrapper.eq("level",level);
            }
            if(!StringUtils.isEmpty(begin)){
                queryWrapper.ge("gmt_create",begin);
            }
            if(!StringUtils.isEmpty(end)){
                queryWrapper.le("gmt_modified",end);
            }
        }

        eduTeacherService.page(teachers,queryWrapper);
        return R.ok().data("total",teachers.getTotal()).data("rows",teachers.getRecords());
    }

    //添加讲师
    @PostMapping("addTeacher")
    public R addTeacher(@RequestBody EduTeacher eduTeacher){
        boolean save = eduTeacherService.save(eduTeacher);
        if(save){
            return R.ok();
        }else {
            return R.error();
        }
    }

    //根据id查询
    @GetMapping("getTeacher/{id}")
    public R getTeacher(@PathVariable String id){
        EduTeacher eduTeacher = eduTeacherService.getById(id);
        return R.ok().data("teacher",eduTeacher);
    }

    //修改讲师
    @PostMapping("updateTeacher")
    public R updateTeacher(@RequestBody EduTeacher eduTeacher){
        boolean flag = eduTeacherService.updateById(eduTeacher);
        if(flag){
            return R.ok();
        }else {
            return R.error();
        }
    }
}


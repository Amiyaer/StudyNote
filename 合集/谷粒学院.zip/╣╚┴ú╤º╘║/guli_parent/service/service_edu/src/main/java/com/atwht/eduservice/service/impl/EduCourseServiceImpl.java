package com.atwht.eduservice.service.impl;

import com.atwht.eduservice.entity.EduCourse;
import com.atwht.eduservice.entity.EduCourseDescription;
import com.atwht.eduservice.entity.vo.CourseInfoVo;
import com.atwht.eduservice.entity.vo.CoursePublishVo;
import com.atwht.eduservice.mapper.EduCourseMapper;
import com.atwht.eduservice.service.EduChapterService;
import com.atwht.eduservice.service.EduCourseDescriptionService;
import com.atwht.eduservice.service.EduCourseService;
import com.atwht.eduservice.service.EduVideoService;
import com.atwht.exceptionhandler.MyException;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 课程 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
@Service
public class EduCourseServiceImpl extends ServiceImpl<EduCourseMapper, EduCourse> implements EduCourseService {
    @Autowired
    private EduCourseDescriptionService descriptionService;
    @Autowired
    private EduChapterService chapterService;
    @Autowired
    private EduVideoService videoService;


    //保存课程信息
    @Override
    public String saveCourseInfo(CourseInfoVo courseInfoVo) {
        //添加课程
        EduCourse eduCourse = new EduCourse();
        BeanUtils.copyProperties(courseInfoVo,eduCourse);
        int insert = baseMapper.insert(eduCourse);
        if(insert == 0){
            throw new MyException(20001,"添加课程失败");
        }
        //获得刚刚插入的课程的课程id，保持课程和课程简介的id一致，以便关联。
        String courseId = eduCourse.getId();
        //添加课程简介
        EduCourseDescription description = new EduCourseDescription();
        description.setDescription(courseInfoVo.getDescription());
        description.setId(courseId);
        descriptionService.save(description);

        return courseId;
    }

    //根据id查询
    @Override
    public CourseInfoVo getCourseInfo(String courseId) {
        //查询课程
        EduCourse course = baseMapper.selectById(courseId);
        CourseInfoVo courseInfoVo = new CourseInfoVo();
        BeanUtils.copyProperties(course,courseInfoVo);
        //查询课程描述
        EduCourseDescription description = descriptionService.getById(courseId);
        courseInfoVo.setDescription(description.getDescription());
        return courseInfoVo;
    }

    //修改课程和课程描述
    @Override
    public void updateCourseInfo(CourseInfoVo courseInfoVo) {
        //修改课程
        EduCourse course = new EduCourse();
        BeanUtils.copyProperties(courseInfoVo,course);
        int update = baseMapper.updateById(course);
        if(update == 0){
            throw new MyException(20001,"修改课程失败!!");
        }
        //修改描述
        EduCourseDescription description = new EduCourseDescription();
        description.setId(courseInfoVo.getId());
        description.setDescription(courseInfoVo.getDescription());
        descriptionService.updateById(description);
    }

    @Override
    public CoursePublishVo getPublishInfo(String id) {
        CoursePublishVo publishVo = baseMapper.getPublishInfoVo(id);
        return publishVo;
    }

    @Override
    public void deleteById(String id) {
        //1.删除章节里的小节
        videoService.removeByCourseId(id);
        //2.删除章节
        chapterService.removeByCourseId(id);
        //3.删除课程描述
        descriptionService.removeById(id);
        //4.删除课程
        int result = baseMapper.deleteById(id);
        if(result == 0){
            throw new MyException(20001,"删除失败");
        }
    }
}

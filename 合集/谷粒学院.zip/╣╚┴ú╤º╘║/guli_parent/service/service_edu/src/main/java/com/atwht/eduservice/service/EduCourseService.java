package com.atwht.eduservice.service;

import com.atwht.eduservice.entity.EduCourse;
import com.atwht.eduservice.entity.vo.CourseInfoVo;
import com.atwht.eduservice.entity.vo.CoursePublishVo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程 服务类
 * </p>
 *
 * @author testjava
 * @since 2020-12-06
 */
public interface EduCourseService extends IService<EduCourse> {

    String saveCourseInfo(CourseInfoVo courseInfoVo);

    CourseInfoVo getCourseInfo(String courseId);

    void updateCourseInfo(CourseInfoVo courseInfoVo);

    CoursePublishVo getPublishInfo(String id);

    void deleteById(String id);
}

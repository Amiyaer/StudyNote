package com.atwht.eduservice.entity.subject;

import lombok.Data;

@Data
public class TwoSubject {
    private String id;
    private String title;
}

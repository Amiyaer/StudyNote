package com.atwht.eduservice.service.impl;

import com.alibaba.excel.EasyExcel;
import com.atwht.eduservice.entity.EduSubject;
import com.atwht.eduservice.entity.excel.SubjectData;
import com.atwht.eduservice.entity.subject.OneSubject;
import com.atwht.eduservice.entity.subject.TwoSubject;
import com.atwht.eduservice.listener.SubjectExcelListener;
import com.atwht.eduservice.mapper.EduSubjectMapper;
import com.atwht.eduservice.service.EduSubjectService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 课程科目 服务实现类
 * </p>
 *
 * @author testjava
 * @since 2020-12-03
 */
@Service
public class EduSubjectServiceImpl extends ServiceImpl<EduSubjectMapper, EduSubject> implements EduSubjectService {

    //添加课程分类
    @Override
    public void saveSubject(MultipartFile file,EduSubjectService subjectService) {
        try {
            //文件输入流
            InputStream inputStream = file.getInputStream();
            //调用方法读取
            EasyExcel.read(inputStream, SubjectData.class,new SubjectExcelListener(subjectService)).sheet().doRead();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //树形全查
    @Override
    public List<OneSubject> getAllOneTwoSubject(){
        //查询一级二级分类
        QueryWrapper<EduSubject> wrapperOne = new QueryWrapper<>();
        wrapperOne.eq("parent_id","0");
        List<EduSubject> listOne = baseMapper.selectList(wrapperOne);
        QueryWrapper<EduSubject> wrapperTwo = new QueryWrapper<>();
        wrapperOne.ne("parent_id","0");
        List<EduSubject> listTwo = baseMapper.selectList(wrapperTwo);
        //封装
        //一级
        List<OneSubject> finalList = new ArrayList<>();
        for(EduSubject one : listOne){
            OneSubject oneSubject = new OneSubject();
            BeanUtils.copyProperties(one,oneSubject);
            finalList.add(oneSubject);
            //二级
            for(EduSubject two : listTwo){
                TwoSubject twoSubject = new TwoSubject();
                BeanUtils.copyProperties(two,twoSubject);
                if(two.getParentId().equals(one.getId())){
                    oneSubject.getChildren().add(twoSubject);
                }
            }
        }
        return finalList;
    }
}

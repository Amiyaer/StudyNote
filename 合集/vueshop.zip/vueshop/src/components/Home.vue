<template>
    <el-container class="home-container">
        <el-header>
            <div>
                <img src="../assets/img/银火龙.png" style="height: 60px">
                <span>后台管理系统</span>
            </div>
            <el-dropdown>
                <el-avatar size="medium" src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png"></el-avatar>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>
                        <el-button @click="logout" type="text">退出</el-button>
                    </el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </el-header>
        <el-container>
            <el-aside :width="isCollapse? '64px' : '200px' ">
                <div class="toggle-button" @click="toggleCollapse">|||</div>
                <!--侧边栏菜单-->
                <el-menu background-color="#333744" text-color="#fff"
                         active-text-color="#409EFF" unique-opened :collapse="isCollapse"
                :collapse-transition="false" :router="true" :default-active="activePath"><!---->

                    <el-submenu :index="item.id +''" v-for="item in menuList" :key="item.id">
                        <template slot="title">
                            <i :class="iconsObj[item.id]"></i>
                            <span>{{item.authName}}</span>
                        </template>

                        <el-menu-item :index="'/'+subItem.path" :key="subItem.id" v-for="subItem in item.children" @click="savePath('/'+subItem.path)">
                            <i class="el-icon-menu"></i>
                            <span>{{subItem.authName}}</span>
                        </el-menu-item>
                    </el-submenu>
                </el-menu>
            </el-aside>
            <el-main>
                <!--路由占位-->
                <router-view></router-view>
            </el-main>
        </el-container>
    </el-container>
</template>

<script>
    export default {
        name: "Home",
        data(){
            return{
                isCollapse:false,
                //被激活的地址
                activePath:this.$route.path,
                menuList:[],
                iconsObj:{
                    '125':'el-icon-user-solid',
                    '103':'el-icon-s-tools',
                    '101':'el-icon-s-goods',
                    '102':'el-icon-s-order',
                    '145':'el-icon-s-data'
                }
            }
        },
        created(){
            this.getMenuList();
            this.activePath=window.sessionStorage.getItem('activePath')
        },
        methods:{
            logout(){
                window.sessionStorage.clear();
                this.$router.push('/login')
            },
            toggleCollapse(){
                //切换菜单的折叠与展开
                this.isCollapse=!this.isCollapse
            },
            savePath(path){
                window.sessionStorage.setItem("activePath", path);
            },
            async getMenuList(){
                const {data: res }=await this.$http.get('menus');
                if(res.meta.status !== 200){
                    return this.$message.error('get data error');
                }
                this.menuList = res.data
            }
        },
    }
</script>
<style scoped src="../assets/css/home.css"/>
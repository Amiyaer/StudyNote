<template>
    <div>
        <!--面包屑导航区-->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>权限管理</el-breadcrumb-item>
            <el-breadcrumb-item>角色列表</el-breadcrumb-item>
        </el-breadcrumb>

        <el-card>
            <el-row>
                <el-col>
                    <el-button type="primary" @click="showAddDialog">添加角色</el-button>
                </el-col>
            </el-row>
            <!--角色列表区域-->
            <el-table :data="roleList" border>
                <el-table-column type="expand">
                    <template v-slot="scope">
                        <!--栅格小布局组件-->
                        <el-row v-for="(item1,i1) in scope.row.children" :key="item1.id" :class="['vcenter','bdbottom',i1 === 0? 'bdtop' : '']">
                            <!--一级到三级权限的渲染-->
                            <el-col :span="5">
                                <el-tag closable @close="removeTag(scope.row,item1.id)">{{item1.authName}}</el-tag>
                                <i class="el-icon-caret-right"></i>
                            </el-col>
                            <el-col :span="19">
                                <!--for循环嵌套渲染2级权限-->
                                <el-row v-for="(item2,i2) in item1.children" :key="item2.id" :class="['vcenter',i2 === 0? '' : 'bdtop']">
                                    <el-col :span="6">
                                        <el-tag type="success" closable @close="removeTag(scope.row,item2.id)">{{item2.authName}}</el-tag>
                                        <i class="el-icon-caret-right"></i>
                                    </el-col>
                                    <el-col :span="18">
                                        <el-tag type="warning" v-for="(item3 , i3) in item2.children" :key="item3.id" closable @close="removeTag(scope.row,item3.id)">{{item3.authName}}</el-tag>
                                    </el-col>
                                </el-row>
                            </el-col>
                        </el-row>
                    </template>
                </el-table-column>
                <el-table-column type="index" label="#"></el-table-column>
                <el-table-column label="角色名称" prop="roleName"></el-table-column>
                <el-table-column label="角色描述" prop="roleDesc"></el-table-column>
                <el-table-column label="操作" width="300px">
                    <template v-slot="scope">
                        <el-button size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row.id)">编辑</el-button>
                        <el-button size="mini" type="danger" icon="el-icon-delete" @click="deleteRole(scope.row.id)">删除</el-button>
                        <el-button size="mini" type="warning" icon="el-icon-setting" @click="showSetRightDialog(scope.row)">分配权限</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>

        <!--添加角色对话框-->
        <el-dialog title="添加角色" :visible.sync="isAddRoleDialog" width="50%"
                   @close="addFormClosed">
            <!--主题区域-->
            <el-form ref="addRoleFormRef" :model="addRoleForm" label-width="80px" :rules="addRoleFormRules">
                <el-form-item label="角色名称" prop="roleName">
                    <el-input v-model="addRoleForm.roleName"></el-input>
                </el-form-item>
                <el-form-item label="角色描述" prop="roleDesc">
                    <el-input v-model="addRoleForm.roleDesc"></el-input>
                </el-form-item>
            </el-form>
            <!--底部-->
            <span slot="footer" class="dialog-footer">
                <el-button @click="isAddRoleDialog = false">取 消</el-button>
                <el-button type="primary" @click="addRoles">确 定</el-button>
            </span>
        </el-dialog>

        <!--修改角色对话框-->
        <el-dialog title="修改角色" :visible.sync="isEditRoleDialog" width="50%"
                   @close="editFormClosed">
            <!--主题区域-->
            <el-form ref="editRoleFormRef" :model="editRoleForm" label-width="80px" :rules="editRoleFormRules">
                <el-form-item label="角色名称" prop="roleName">
                    <el-input v-model="editRoleForm.roleName"></el-input>
                </el-form-item>
                <el-form-item label="角色描述" prop="roleDesc">
                    <el-input v-model="editRoleForm.roleDesc"></el-input>
                </el-form-item>
            </el-form>
            <!--底部-->
            <span slot="footer" class="dialog-footer">
                <el-button @click="isEditRoleDialog = false">取 消</el-button>
                <el-button type="primary" @click="editRole(editRoleForm.roleId)">确 定</el-button>
            </span>
        </el-dialog>

        <!--分配权限对话框-->
        <el-dialog title="分配权限" :visible.sync="isShowSetRightDialog" width="50%"
        @close="setRightDialogClose">
            <!--主题区域-->
            <el-tree :data="rightlist" ref="treeRef" :props="defaultProps" show-checkbox
            node-key="id" default-expand-all :default-checked-keys="defKeys"></el-tree>
            <!--底部-->
            <span slot="footer" class="dialog-footer">
                <el-button @click="isShowSetRightDialog = false">取 消</el-button>
                <el-button type="primary" @click="allotRights">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "Roles",
        data(){
            return{
                roleList:[],
                rightlist:[],
                //默认选中的节点id数组
                defKeys:[],
                isShowSetRightDialog:false,
                //即将分配权限的角色的id
                roleId:'',
                defaultProps:{
                    children:'children',
                    label:'authName'
                },
                //添加角色对话框
                isAddRoleDialog:false,
                //添加角色的表单
                addRoleForm:{
                    roleName:'',
                    roleDesc:''
                },
                addRoleFormRules:{
                    roleName:[{required:true,message:'请输入角色名称',trigger:'blur'}]
                },
                //修改角色对话框
                isEditRoleDialog:false,
                //修改角色的表单
                editRoleForm:{
                    roleId:0,
                    roleName:'',
                    roleDesc:''
                },
                editRoleFormRules:{
                    roleName:[{required:true,message:'请输入角色名称',trigger:'blur'}]
                },
            }
        },
        created() {
            this.getRolesList()
        },
        methods:{
             async getRolesList(){
                const {data: res}= await this.$http.get('roles')
                 if(res.meta.status !== 200){
                     return console.log("获取角色失败")
                 }
                 this.roleList = res.data
            },
            //根据id删除权限
            removeTag(role, id){
                this.$confirm('此操作将永久删除权限, 是否继续?', '提示', {
                    confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning'
                }).then(async () => {
                    const {data: res} = await this.$http.delete(`roles/${role.id}/rights/${id}`)
                    if(res.meta.status !== 200){
                        return this.$message.error('删除权限失败')
                    }
                    //this.$message.success('删除成功!');
                    //this.getRolesList()
                    //防止列表刷新
                    role.children = res.data
                }).catch(() => {
                    this.$message.info( '已取消删除');
                });
            },
            //显示分配权限对话框
            async showSetRightDialog(role){
                 const {data: res} =await this.$http.get('rights/tree');
                 if(res.meta.status !== 200){
                     return this.$message.error('获取权限数据失败')
                 }
                //获取到的权限数据
                this.rightlist = res.data;
                this.getLeafKeys(role ,this.defKeys)
                this.roleId=role.id
                this.isShowSetRightDialog = true
            },
            //获取勾选的节点
            getLeafKeys(node ,arr){
                 if(!node.children){
                     //确认是三级节点，把他们的id放入数组
                     return arr.push(node.id)
                 }
                 //否则遍历children
                 node.children.forEach(item =>{
                     this.getLeafKeys(item ,arr)
                 })
            },
            //关闭对话框时清空之前的数组
            setRightDialogClose(){
                 this.defKeys = []
                this.roleId=''
            },
            //分配权限
            async allotRights(){
                 const keys = [
                     //es6新语法
                     ...this.$refs.treeRef.getCheckedKeys(),
                     ...this.$refs.treeRef.getHalfCheckedKeys()
                 ]
                const idStr = keys.join(',')
                const {data: res} = await this.$http.post(`roles/${this.roleId}/rights`,{ rids: idStr})
                if(res.meta.status !== 200){
                    return this.$message.error('分配权限失败')
                }
                this.$message.success('分配权限成功！')
                this.getRolesList()
                this.isShowSetRightDialog = false
             },
            //展示添加角色对话框
            showAddDialog(){
                 this.isAddRoleDialog = true
            },
            //对话框关闭重置事件
            addFormClosed(){
                 this.$refs.addRoleFormRef.resetFields()
            },
            //添加角色事件
            addRoles(){
                 this.$refs.addRoleFormRef.validate(async valid =>{
                     if (!valid){return }
                     const {data : res} = await this.$http.post('roles',
                         {roleName:this.addRoleForm.roleName,
                                 roleDesc:this.addRoleForm.roleDesc})
                     if(res.meta.status !== 201){
                         return this.$message.error('添加角色失败！')
                     }
                     this.$message.success('添加角色成功！')
                     this.getRolesList()
                     this.isAddRoleDialog = false
                 })
            },
            //展示修改角色对话框
            async showEditDialog(id){
                const {data : res} = await this.$http.get(`roles/${id}`)
                if(res.meta.status !== 200){
                    return this.$message.error('查询角色失败！')
                }
                this.editRoleForm = res.data
                this.isEditRoleDialog = true
            },
            //对话框关闭重置事件
            editFormClosed(){
                this.$refs.editRoleFormRef.resetFields()
            },
            //修改角色事件
            editRole(id){
                 this.$refs.editRoleFormRef.validate(async valid =>{
                     if (!valid){return }
                     const {data : res} = await this.$http.put(`roles/${id - 0}`,
                         {roleName:this.editRoleForm.roleName,
                             roleDesc:this.editRoleForm.roleDesc})
                     if(res.meta.status !== 200){
                         return this.$message.error('修改角色失败！')
                     }
                     this.$message.success('修改角色成功！')
                     this.getRolesList()
                     this.isEditRoleDialog = false
                 })
            },
            //删除角色事件
            deleteRole(id){
                this.$confirm('此操作将永久删除角色, 是否继续?', '提示', {
                    confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning'
                }).then(async () => {
                    const {data: res} = await this.$http.delete('roles/'+id)
                    if(res.meta.status !== 200){
                        return this.$message.error('删除角色失败')
                    }
                    this.$message.success('删除角色成功!');
                    this.getRolesList()
                }).catch(() => {
                    this.$message.info( '已取消删除');
                });
            }
        }
    }
</script>

<style scoped>
    .el-tag{
        margin: 7px;
    }

    .bdtop{
        border-top: 1px solid #eeeeee;
    }

    .bdbottom{
        border-bottom: 1px solid #eeeeee;
    }
    .vcenter{
        display: flex;
        align-items: center;
    }
</style>
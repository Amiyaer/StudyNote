<template>
    <div>
        <!--面包屑导航区-->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>商品管理</el-breadcrumb-item>
            <el-breadcrumb-item>商品分类</el-breadcrumb-item>
        </el-breadcrumb>

        <!--卡片视图-->
        <el-card class="box-card">
            <el-row :gutter="20">
                <el-col :span="4">
                    <el-button type="primary" @click="showAddDialog()">添加分类</el-button>
                </el-col>
            </el-row>
            <!--table-->
            <tree-table :data="cateList" :columns="columns" border class="treeTable"
                        :selection-type="false" :expand-type="false" show-index index-text="#">
                <!--是否有效-->
                <template v-slot:isEffective="scope">
                    <i class="el-icon-success" v-if="scope.row.cat_deleted === false" style="color: lightgreen"></i>
                    <i class="el-icon-error" v-else style="color: red"></i>
                </template>
                <!--排序-->
                <template v-slot:order="scope">
                    <el-tag v-if="scope.row.cat_level === 0">一级排序</el-tag>
                    <el-tag type="success" v-if="scope.row.cat_level === 1">二级排序</el-tag>
                    <el-tag type="warning" v-if="scope.row.cat_level === 2">三级排序</el-tag>
                </template>
                <!--操作-->
                <template v-slot:option="scope">
                    <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(scope.row.cat_id)">编辑</el-button>
                    <el-button type="danger" icon="el-icon-delete" size="mini" @click="deleteCate(scope.row.cat_id)">删除</el-button>
                </template>
            </tree-table>

            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                    :current-page="queryInfo.pagenum" :page-sizes="[1, 3, 5 ,10 ,15]" :page-size="queryInfo.pagesize"
                    layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
        </el-card>

        <!--添加分类对话框-->
        <el-dialog title="添加分类" :visible.sync="addCateDialogVisible" width="50%"
                   @close="resetCateForm">
            <!--主题区域-->
            <el-form ref="addCateFormRef" :model="addCateForm" label-width="80px" :rules="addCateFormRules">
                <el-form-item label="分类名称" prop="cat_name">
                    <el-input v-model="addCateForm.cat_name"></el-input>
                </el-form-item>
                <el-form-item label="父级分类">
                    <!--级联选择框-->
                    <!--options指定数据源-->
                    <!--props指定配置-->
                    <el-cascader v-model="value" :options="parentCateList" :props="cascaderProps"
                            @change="parentCateChanged" clearable></el-cascader>
                </el-form-item>
            </el-form>
            <!--底部-->
            <span slot="footer" class="dialog-footer">
                <el-button @click="addCateDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="addCate">确 定</el-button>
            </span>
        </el-dialog>

        <!--修改商品分类对话框-->
        <el-dialog title="修改分类" :visible.sync="editCateDialogVisible" width="50%" @close="resetEditCateForm">
            <!--主题区域-->
            <el-form ref="editCateFormRef" :model="editCateForm" label-width="80px" :rules="editCateFormRules">
                <el-form-item label="分类名称" prop="cat_name">
                    <el-input v-model="editCateForm.cat_name"></el-input>
                </el-form-item>
                <el-form-item label="父级分类">
                    <!--级联选择框-->
                    <!--options指定数据源-->
                    <!--props指定配置-->
                    <el-cascader v-model="editValue" :options="parentCateList" :props="cascaderProps"
                                 :placeholder="editLabel" @change="editCateChanged" clearable disabled></el-cascader>
                </el-form-item>
            </el-form>
            <!--底部-->
            <span slot="footer" class="dialog-footer">
                <el-button @click="editCateDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="editCate">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "Cate",
        data(){
            return{
                //查询条件
                queryInfo:{
                    type:3,
                    pagenum:1,
                    pagesize:5
                },
                //商品分类数据列表
                cateList:[],
                //总数据条数
                total:0,
                //为table指定列的定义
                columns:[{
                    label:'分类名称',
                    prop:'cat_name'
                },{
                    label:'是否有效',
                    type:'template',
                    template:'isEffective'
                },{
                    label:'排序',
                    type:'template',
                    template:'order'
                },{
                    label:'操作',
                    type:'template',
                    template:'option'
                }],
                //是否显示对话框
                addCateDialogVisible:false,
                editCateDialogVisible:false,
                //表单
                addCateForm:{
                    cat_name:'',
                    //父类别id
                    cat_pid:0,
                    //分类等级，默认为一级分类
                    cat_level:0
                },
                editCateForm:{
                    cat_name:'',
                    //父类别id
                    cat_pid:0,
                    //分类等级，默认为一级分类
                    cat_level:0
                },
                //添加分类验证规则
                addCateFormRules:{
                    cat_name:[
                        {required:true,
                            message:'请输入分类名称',
                            trigger:'blur'}
                    ]
                },
                editCateFormRules:{
                    cat_name:[
                        {required:true,
                            message:'请输入分类名称',
                            trigger:'blur'}
                    ]
                },
                //父级分类列表
                parentCateList:[],
                //配置
                cascaderProps:{
                    expandTrigger: 'hover',
                    value:'cat_id',
                    label:'cat_name',
                    children:'children',
                    checkStrictly:true
                },
                //(添加表单中)选中的父级分类的数组，必须是一个数组
                value:[],
                //(修改表单中)选中的父级分类的数组，必须是一个数组
                editValue:[],
                //修改表单中级联选择器回显默认显示值
                editLabel:'',
                //当前选择要修改的分类的ID
                editId:0
            }
        },
        created() {
            this.getCateList();
        },
        methods:{
            async getCateList(){
                const {data: res} = await this.$http.get('categories',{params: this.queryInfo})
                if(res.meta.status !== 200){
                    return this.$message.error('获取商品分类失败')
                }
                this.cateList = res.data.result
                this.total = res.data.total
            },
            handleSizeChange(newSize){
                this.queryInfo.pagesize = newSize
                this.getCateList()
            },
            handleCurrentChange(newPageNum){
                this.queryInfo.pagenum = newPageNum
                this.getCateList()
            },
            //展示对话框
            async showAddDialog(){
                this.getParentCateList()
                this.addCateDialogVisible = true
            },
            async showEditDialog(id){
                this.getParentCateList()
                //根据ID查询分类并展示
                const {data : res} = await this.$http.get(`categories/
                    ${id}`)
                if(res.meta.status !== 200){
                    return this.$message.error('获取商品分类失败！')
                }
                this.editId = id
                this.editCateForm.cat_name = res.data.cat_name
                this.findLabel(res.data.cat_name)
                this.editCateDialogVisible = true
            },
            //获取父级分类
            async getParentCateList(){
                const {data: res} =await this.$http.get('categories',{ params: { type: 2} });
                if( res.meta.status !== 200 ){
                    return this.$message.error('获取父级分类失败！')
                }
                this.parentCateList = res.data
            },
            //选中的父级分类发生改变
            parentCateChanged(){
                if(this.value.length > 0){
                    this.addCateForm.cat_pid = this.value[this.value.length-1]
                    this.addCateForm.cat_level=this.value.length
                } else {
                    this.addCateForm.cat_pid = 0
                    this.addCateForm.cat_level = 0
                }
            },
            //修改选中的父级分类改变
            editCateChanged(){
                if(this.editValue.length > 0){
                    this.editCateForm.cat_pid = this.editValue[this.editValue.length-1]
                    this.editCateForm.cat_level=this.editValue.length
                } else {
                    this.editCateForm.cat_pid = 0
                    this.editCateForm.cat_level = 0
                }
            },
            //重置表单
            resetCateForm(){
                this.$refs.addCateFormRef.resetFields();
                this.value = []
                this.addCateForm.cat_pid = 0
                this.addCateForm.cat_level = 0
            },
            resetEditCateForm(){
                this.$refs.editCateFormRef.resetFields();
                this.editValue = []
                this.addCateForm.cat_pid = 0
                this.addCateForm.cat_level = 0
                this.editId = 0
            },
            //添加新的分类
            addCate(){
                this.$refs.addCateFormRef.validate(async valid => {
                    if(!valid) return
                    const {data: res} = await this.$http.post('categories',this.addCateForm)
                    if(res.meta.status !== 201){
                        return  this.$message.error('添加分类失败')
                    }

                    this.$message.success('添加分类成功！')
                    this.getCateList()
                    this.addCateDialogVisible = false
                })
            },
            //删除分类
            deleteCate(id){
                console.log(id)
                this.$confirm('此操作将永久删除商品分类, 是否继续?', '提示', {
                    confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning'
                }).then(async () => {
                    const {data: res} = await this.$http.delete('categories/'+id)
                    if(res.meta.status !== 200){
                        return this.$message.error('删除商品分类失败')
                    }
                    this.$message.success('删除商品分类成功!');
                    this.getCateList()
                }).catch(() => {
                    this.$message.info( '已取消删除');
                });
            },
            //提交修改分类
            editCate(){
                this.$refs.editCateFormRef.validate(async valid =>{
                    if(!valid) return
                    const {data : res} = await this.$http.put(`categories/${this.editId}`,
                        {cat_name:this.editCateForm.cat_name})
                    if(res.meta.status !== 200){
                        return this.$message.error('修改商品分类失败！')
                    }
                    this.$message.success('修改商品分类成功！')
                    this.getCateList()
                    this.editCateDialogVisible = false
                })
            },
            //回显
            findLabel(catName){
                //第一阶级
                const firstCate = this.cateList
                let secondCate = []
                let thirdCate = []
                for(let i = 0;i<firstCate.length;i++){
                    if(catName !== firstCate[i].cat_name){
                        //第二阶级
                        if(firstCate[i].children === undefined){
                            continue
                        }else{
                            secondCate = firstCate[i].children
                            for(let j = 0;j < secondCate.length ;j++){
                                if(catName !== secondCate[j].cat_name){
                                    //第三阶级
                                    if(firstCate[i].children === undefined){
                                        continue
                                    }else{
                                        thirdCate = secondCate[j].children
                                        for(let k = 0;k<thirdCate.length;k++){
                                            if(catName === thirdCate[k].cat_name){
                                                this.editLabel = firstCate[i].cat_name + '/' + secondCate[j].cat_name
                                                return
                                            }
                                        }
                                    }
                                }else {
                                    this.editLabel = firstCate[i].cat_name
                                    return
                                }
                            }
                        }

                    }else{
                        this.editLabel = ''
                        return
                    }
                }
            }
        }
    }
</script>

<style scoped>
    .treeTable{
        margin-top: 15px;
        margin-bottom: 15px;
    }
    .el-cascader{
        width: 100%;
    }
    .el-input{
        width: 100%;
    }
    .el-form-item{
        width: 100%;
    }
</style>
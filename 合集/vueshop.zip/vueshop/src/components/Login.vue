<template>
    <div class="login_container">
        <div class="login_box">
            <div class="avatar_box">
                <img src="../assets/logo.png">
            </div>
            <el-form class="login_form" ref="loginFormRef" :model="loginForm" :rules="loginFormRules">
                <el-form-item prop="username">
                    <el-input v-model="loginForm.username" prefix-icon="el-icon-s-custom"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input v-model="loginForm.password" prefix-icon="el-icon-s-cooperation" type="password"></el-input>
                </el-form-item>
                <el-form-item class="btns">
                    <el-button type="primary" @click="login">登录</el-button>
                    <el-button type="info" @click="resetLoginForm">重置</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Login",
        data(){
            return{
                loginForm:{
                    username:'admin',
                    password:'123456'
                },
                //表单验证,需要在el-form-item加上prop
                loginFormRules:{
                    username:[
                        {required:true,message:'输入用户名',trigger:'blur'},
                        {min:3,max:10,message:'长度在3到10个字符',trigger: 'blur'}
                    ],
                    password:[
                        {required:true,message:'输入密码',trigger:'blur'},
                        {min:6,max:15,message:'长度在6到15个字符',trigger: 'blur'}
                    ]
                }
            }
        },
        methods:{
            resetLoginForm(){
                this.$refs.loginFormRef.resetFields();
            },
            login(){
                this.$refs.loginFormRef.validate(async (valid) =>{
                    if(!valid){
                        return;
                    }
                    //发送请求并验证
                    const {data: res}=await this.$http.post('login',this.loginForm);
                    if(res.meta.status !== 200){
                        return this.$message.error("登陆失败");
                    }else{
                        this.$message.success('登录成功');
                        //设置token访问权限
                        window.sessionStorage.setItem('token',res.data.token);
                        this.$router.push('/home');
                    }
                });
            }
        }
    }
</script>

<style scoped src="../assets/css/login.css"/>